package ru.mtr.practice.example.app1.frontend

import react.PropsWithChildren
import react.fc
import react.router.Navigate
import ru.mtr.practice.example.app1.common.CurrentSession
import ru.mtr.practice.example.app1.frontend.utils.useCoroutine
import ru.mtr.practice.example.app1.frontend.utils.useStateFlow

/**
 * Этот компонент проверяет авторизацию рисует вложенные в него компоненты только, если мы авторизованы
 * иначе он перенаправляет на /login.
 */
val CheckAuth = fc<PropsWithChildren>("Check Auth") {
	val scope = useCoroutine()
	val successLogin by scope.useStateFlow(CurrentSession.isLogin)
	if (successLogin) {
		it.children()
	} else {
		Navigate {
			attrs.to = "/login"
			attrs.replace = true
		}
	}
}