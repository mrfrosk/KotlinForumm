package ru.mtr.practice.example.app1.frontend

import kotlinx.browser.document
import kotlinx.browser.window
import react.buildElement
import react.dom.client.Root
import react.dom.client.createRoot

/**
 * Это точка входа
 */
fun main() {
    /**
     * Подписка на событие загрузки нужно для того,
     * что бы код начал выполняться только тогда,
     * когда страница будет полностью загружена.
     */
    window.onload = {
        document.getElementById("root")?.let { rootDiv ->
            val root: Root = createRoot(rootDiv)
            root.render(buildElement { child(ForumWebAppRouter) })
        }
    }
}


