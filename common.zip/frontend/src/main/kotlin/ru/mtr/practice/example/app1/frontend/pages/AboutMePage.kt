package ru.mtr.practice.example.app1.frontend.pages

import mui.material.*
import react.fc
import styled.StyledProps
import styled.styled
import styled.styledH1


/**
 * Страница, в которой должна быть информация о текущем пользователе.
 * То есть о том, который авторизован по версии [ru.fire.sign.practise.forum.frontend.services.CurrentSession]
 */
val AboutMePage = fc<StyledProps>("About Me Page") {
	styled(Box)() {
		styledH1 {
			+"Обо мне"
		}
	}
}