package ru.mtr.practice.example.app1.frontend.pages

import io.ktor.client.call.*
import kotlinx.coroutines.launch
import mui.material.Box
import mui.material.Button
import mui.material.ButtonGroup
import react.fc
import react.useState
import ru.mtr.practice.example.app1.common.ExampleRestClient
import ru.mtr.practice.example.app1.common.ManageUsers
import ru.mtr.practice.example.app1.common.dto.LoginDto
import ru.mtr.practice.example.app1.common.dto.RegistrationDto
import ru.mtr.practice.example.app1.frontend.utils.useCoroutine
import styled.StyledProps
import styled.styled
import styled.styledH1

/**
 * Тут должны быть темы, т.е. диалоги, которые создают пользователи на форуме.
 * Возможно, что тут потребуется ещё один блок роутов. А может и нет. Смотря как будете делать.
 */


val ThemesPage = fc<StyledProps>("Themes Page") {
	val scope = useCoroutine()
	val client = ExampleRestClient
	val user = ManageUsers()
	var login by useState(false)
	var counter by useState(0)
	var msg by useState("")
	var msg2 by useState("")
	styled(Box)() {
		styledH1 {
			+"Темы"
		}
		ButtonGroup {
			Button {
				attrs.onClick = {
					scope.launch {
						counter = client.sampleRequest1()

					}
				}
				+"$msg #$counter #$login"
			}
		}
	}
}