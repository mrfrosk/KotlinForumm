package ru.mtr.practice.example.app1.frontend

import mui.material.Box
import mui.material.Button
import react.fc
import react.router.Outlet
import react.router.dom.Link
import react.router.useNavigate
import ru.mtr.practice.example.app1.common.CurrentSession
import styled.StyledProps
import styled.styled
import styled.styledNav

/**
 * Основной компонент Форума для авторизованных пользователей.
 */
val ForumWebAppBody = fc<StyledProps>("Forum Web Application Body") {
	val navigate = useNavigate()
	styled(Box)() {
		styledNav {
			/**
			 * Link нужен для того, что бы создавать ссылку, нажатие на которую перенаправляет нас по соответствующему адресу.
			 */
			Link {
				/**
				 * Адрес, по которому ссылка направляет пользователя должен совпадать с одним из роутов. (роуты в ForumWebAppRouter)
				 */
				attrs.to = "about-me"
				styled(Button)() {
					+"Обо мне"
				}
			}
			Link {
				attrs.to = "themes"
				styled(Button)() {
					+"Темы"
				}
			}
			styled(Button)() {
				attrs.onClick = {
					CurrentSession.logout()
					navigate(0)
				}
				+"Выйти"
			}
		}
	}
	Outlet {}
}