package ru.mtr.practice.example.app1.frontend.utils

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.w3c.dom.HTMLInputElement
import org.w3c.dom.events.Event
import react.dom.events.BaseSyntheticEvent
import react.useEffect
import react.useState
import kotlin.properties.ReadOnlyProperty
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

fun useCoroutine() = MainScope().also { useEffect { cleanup { it.cancel() } } }

val BaseSyntheticEvent<*, *, *>.targetValue get() = (target as HTMLInputElement).value

val Event.targetValue get() = (target as HTMLInputElement).value

fun <T, V> CoroutineScope.useStateFlow(stateFlow: StateFlow<V>): ReadOnlyProperty<T, V> {
	var state by useState { stateFlow.value }
	val job = launch { stateFlow.collect {if(it!=state) state = it } }
	useEffect { cleanup { job.cancel() } }
	return ReadOnlyProperty { _, _ -> state }
}

fun <T, V> CoroutineScope.useMutableStateFlow(mutableStateFlow: MutableStateFlow<V>): ReadWriteProperty<T, V> {
	var state by useState { mutableStateFlow.value }
	val job = launch { mutableStateFlow.collect {if(it!=state) state = it } }
	useEffect { cleanup { job.cancel() } }
	return object : ReadWriteProperty<T, V> {
		override fun getValue(thisRef: T, property: KProperty<*>): V = state

		override fun setValue(thisRef: T, property: KProperty<*>, value: V) {
			mutableStateFlow.value = value
		}
	}
}