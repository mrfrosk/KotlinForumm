package ru.mtr.practice.example.app1.frontend.pages
import csstype.Border
import csstype.HtmlAttributes
import csstype.LineStyle
import io.ktor.util.*
import kotlinx.coroutines.launch
import kotlinx.css.*
import kotlinx.html.FormMethod
import kotlinx.html.InputType
import kotlinx.html.js.onChangeFunction
import kotlinx.js.jso
import mui.material.Box
import mui.material.Button
import org.w3c.dom.HTMLInputElement
import react.dom.*
import react.fc
import react.router.useNavigate
import react.useState
import ru.mtr.practice.example.app1.common.CurrentSession
import ru.mtr.practice.example.app1.common.ManageUsers
import ru.mtr.practice.example.app1.common.dto.RegistrationDto
import ru.mtr.practice.example.app1.frontend.utils.useCoroutine
import ru.mtr.practice.example.app1.frontend.utils.useMutableStateFlow
import styled.StyledProps
import styled.css
import styled.styled
import styled.styledH1

/**
 * �������� �����������
 */
val Registr = fc<StyledProps>("Registr") {
    val scope = useCoroutine()
//    var prim by useState(0)
    val manageUser = ManageUsers()
    var log by useState(" ")
    var usr by useState(" ")
    var pas by useState(" ")
    var regist by useState(false)
    var successLogin by scope.useMutableStateFlow(CurrentSession.isLogin)
    val navigate = useNavigate()
    styled(Box)() {
        css{
            textAlign = TextAlign.center
        }
        styledH1 {
            css {
                color = Color.green
            }
            +"�����������!!!!!"
        }
//        label{
//            p{  + "��� ������ ���� ������� $usr"}
//        }
//        label{
//            p{  + "��� ������ ���� ����� $log"}
//        }
//        label{
//            p{  + "��� ������ ���� ������ $pas"}
//        }
//        Button{
//            attrs.onClick = {
//                prim += 1
//            }
//            + " ���  $prim"
//        }
        div{

            label {
                p { +"Username" }
            }
            input(type = InputType.email, name = "Username") {
                attrs {
                    placeholder = " Input username"
                }
                attrs.onChangeFunction = {
                    usr = (it.target as HTMLInputElement).value
                }
            }
            label {
                p { +"Email" }
            }
            input(type = InputType.email, name = "Email") {
                attrs {
                    placeholder = " Input email"
                }
                attrs.onChangeFunction = {
                    log = (it.target as HTMLInputElement).value
                }
            }
            label {
                p { + "Password" }
            }
            input(type = InputType.password, name = "Password") {
                attrs{
                    placeholder = " Input password"
                }
                attrs.onChangeFunction = {
                    pas = (it.target as HTMLInputElement).value
                }
            }
        }
        Button {
            attrs.onClick = {
                scope.launch {
                    regist = manageUser.regUser(RegistrationDto(log,pas,usr))
                    println(regist)
                }

            }
            + "������������������"
        }
        if(regist) {
            CurrentSession.login()
            successLogin = true
        }
    }
    if (successLogin) {
        navigate("/about-me", jso {
            replace = true
        })
    }
}