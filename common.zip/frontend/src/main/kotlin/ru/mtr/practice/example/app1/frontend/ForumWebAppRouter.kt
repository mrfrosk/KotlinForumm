package ru.mtr.practice.example.app1.frontend

import react.buildElement
import react.fc
import react.router.Navigate
import react.router.Route
import react.router.Routes
import react.router.dom.HashRouter
import ru.mtr.practice.example.app1.frontend.pages.AboutMePage
import ru.mtr.practice.example.app1.frontend.pages.LoginPage
import ru.mtr.practice.example.app1.frontend.pages.Registr
import ru.mtr.practice.example.app1.frontend.pages.ThemesPage
import styled.StyledProps

val ForumWebAppRouter = fc<StyledProps>("Forum Web Application Router") {
	HashRouter {

		Routes {
			Route {
				attrs.path = "/"
				attrs.element = buildElement { CheckAuth { ForumWebAppBody {} } }

				Route {
					attrs.path = "about-me"
					attrs.element = buildElement { AboutMePage {} }
					attrs.index = true
				}
				Route {
					attrs.path = "themes"
					attrs.element = buildElement { ThemesPage {} }
				}
				Route {
					attrs.path = "*"
					attrs.element = buildElement { Navigate { attrs.to = "about-me" } }
				}
			}
			/**
			 * Роут авторизации находится тут, что бы быть на одном уровне с корневым и перехватывать всех, кто не авторизован.
			 */
			Route {
				attrs.path = "login"
				attrs.element = buildElement { LoginPage {} }

			}
			Route{
				attrs.path = "Registr"
				attrs.element = buildElement { Registr {} }
			}
		}
	}
}