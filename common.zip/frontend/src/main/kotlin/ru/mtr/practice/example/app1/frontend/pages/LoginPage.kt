package ru.mtr.practice.example.app1.frontend.pages

import csstype.HtmlAttributes
import io.ktor.util.*
import kotlinx.coroutines.launch
import kotlinx.css.*
import kotlinx.html.InputType
import kotlinx.html.js.onChangeFunction
import kotlinx.html.onClick
import kotlinx.js.jso
import mui.material.Box
import mui.material.Button
import org.w3c.dom.HTMLInputElement
import react.dom.*
import react.fc
import react.router.useNavigate
import react.useEffect
import react.useLayoutEffect
import react.useState
import ru.mtr.practice.example.app1.common.CurrentSession
import ru.mtr.practice.example.app1.common.ManageUsers
import ru.mtr.practice.example.app1.common.dto.LoginDto
import ru.mtr.practice.example.app1.frontend.utils.useCoroutine
import ru.mtr.practice.example.app1.frontend.utils.useMutableStateFlow
import styled.StyledProps
import styled.css
import styled.styled
import styled.styledH1

/**
 * Страница авторизации
 */
val LoginPage = fc<StyledProps>("Login Page") {
	val scope = useCoroutine()
	val manageUser = ManageUsers()
	var prim by useState(0)
	var log by useState(" ")
	var pas by useState(" ")
	var autorized by useState(false)
	var successLogin by scope.useMutableStateFlow(CurrentSession.isLogin)
	val navigate = useNavigate()
	styled(Box)() {
		css{
			textAlign = TextAlign.center
		}
		styledH1 {
			css {
				color = Color.red
			}
			+"Авторизация!!!!!"
		}
//		Button{
//			attrs.onClick = {
//				prim = prim + 1
//			}
//			+ " зип  $prim"
//		}
		div{
			label {
				p { +"Email" }
			}
			input(type = InputType.email, name = "Email") {
				attrs {
					placeholder = " Input email"
				}
				attrs.onChangeFunction = {
					log = (it.target as HTMLInputElement).value
				}
			}
			label {
				p { + "Password" }
			}
			input(type = InputType.password, name = "Password") {
				attrs{
					placeholder = " Input password"
				}
				attrs.onChangeFunction = {
					pas = (it.target as HTMLInputElement).value
				}
			}
		}
//		label { p{+ " Тут записывается логин $log и пароль $pas"} }
		Button {
			attrs.onClick = {
				scope.launch {
					autorized =  manageUser.logUser(LoginDto(log,pas))
				}
			}
			+ "Войти"
		}
		if(autorized) {
			CurrentSession.login()
			successLogin = true
		}
		Button {
			attrs.onClick = {
				navigate("/registr", jso {
					replace = true
				})
			}
			+"Регистрация"
		}
	}
	if (successLogin) {
		navigate("/about-me", jso {
			replace = true
		})
	}
}