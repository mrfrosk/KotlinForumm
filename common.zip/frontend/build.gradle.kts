plugins {
	apply {
		kotlin("js")
		kotlin("plugin.serialization")

	}
}
fun Project.requireProject(name: String) =
	rootProject.findProject(name) ?: throw Exception("Проект с именем '$name' не найден.")

kotlin {
	js(org.jetbrains.kotlin.gradle.plugin.KotlinJsCompilerType.LEGACY) {
		browser {
			commonWebpackConfig {
				cssSupport.enabled = true
			}
		}
		binaries.executable()
	}
}

group = "ru.mtr.practice.example"
version = "0.0.1-SNAPSHOT"
java.sourceCompatibility = JavaVersion.VERSION_13

dependencies {
	implementation(kotlin("stdlib"))
	implementation(kotlin("reflect"))
	implementation(kotlin("serialization"))
	implementation("org.jetbrains.kotlinx:kotlinx-serialization-json")
	implementation("org.jetbrains.kotlinx:kotlinx-datetime")
	implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core")
	implementation("org.jetbrains.kotlinx:kotlinx-coroutines-io")
	implementation("com.benasher44:uuid")

	// ktor
	implementation("io.ktor:ktor-client-core")
	implementation("io.ktor:ktor-client-logging")

	implementation(npm("js-base64", "3.7.2"))
	implementation(npm("uuid", "8.3.2"))

	implementation("org.jetbrains.kotlin-wrappers:kotlin-react")
	implementation("org.jetbrains.kotlin-wrappers:kotlin-react-dom")
	implementation("org.jetbrains.kotlin-wrappers:kotlin-react-dom")
	implementation("org.jetbrains.kotlin-wrappers:kotlin-styled")
	implementation("org.jetbrains.kotlin-wrappers:kotlin-react-router-dom")
	implementation("org.jetbrains.kotlin-wrappers:kotlin-redux")
	implementation("org.jetbrains.kotlin-wrappers:kotlin-react-virtual")
	implementation("org.jetbrains.kotlin-wrappers:kotlin-mui")
	implementation("org.jetbrains.kotlin-wrappers:kotlin-mui-icons")
	implementation("org.jetbrains.kotlin-wrappers:kotlin-react-redux")


	implementation(npm("@js-joda/timezone", "2.5.0"))
	implementation(npm("js-joda-locale", "1.1.0-pre5"))
	implementation(npm("react-select-virtualized", "3.5.0"))
	implementation(npm("react-select", "4.3.1"))
	implementation(npm("react-virtualized", "9.22.3"))
	implementation(npm("@material-ui/core", "4.12.4"))
	implementation(npm("@material-ui/lab", "4.0.0-alpha.61"))
	implementation(npm("@material-ui/icons", "4.11.3"))
	implementation(npm("@material-ui/styles", "4.11.5"))
	implementation(npm("@emotion/styled", "11.8.1"))

	implementation(requireProject(":common"))

}