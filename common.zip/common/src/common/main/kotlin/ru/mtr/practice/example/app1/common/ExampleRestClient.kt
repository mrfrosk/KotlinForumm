package ru.mtr.practice.example.app1.common

import io.ktor.client.call.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.utils.io.charsets.*
import ru.mtr.practice.example.app1.common.dto.ExampleDto

object ExampleRestClient {
	val http = Kernel.http

	suspend fun sampleRequest1(): Int {

		return http.get(Kernel.buildUrl("example/sample-request-1")).body()
	}

	suspend fun sampleRequest2(): ExampleDto = http.get(Kernel.buildUrl("example/sample-request-2")) {
		accept(ContentType.Application.Json.withCharset(Charsets.UTF_8))
	}.body()



}