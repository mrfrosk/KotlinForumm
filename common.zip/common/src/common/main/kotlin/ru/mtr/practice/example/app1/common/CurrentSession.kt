package ru.mtr.practice.example.app1.common

import kotlinx.coroutines.flow.MutableStateFlow

object CurrentSession {
	val isLogin = MutableStateFlow(false)

	fun login() {
		isLogin.value = true

	}

	fun logout() {
		isLogin.value = false
	}
}