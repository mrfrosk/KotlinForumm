package ru.mtr.practice.example.app1.common

import io.ktor.client.call.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import io.ktor.utils.io.charsets.*
import ru.mtr.practice.example.app1.common.Kernel.http
import ru.mtr.practice.example.app1.common.dto.LoginDto
import ru.mtr.practice.example.app1.common.dto.RegistrationDto


class ManageUsers {

    suspend fun logUser(userInfo: LoginDto): Boolean {
        return http.post(Kernel.buildUrl("db/user-login")) {
            setBody(userInfo)
            contentType(ContentType.Application.Json.withCharset(Charsets.UTF_8))
        }.body()
    }

    suspend fun regUser(userInfo: RegistrationDto): Boolean{
        return http.post(Kernel.buildUrl("db/user-registration")) {
            setBody(userInfo)
            contentType(ContentType.Application.Json.withCharset(Charsets.UTF_8))
        }.body()

    }


}








