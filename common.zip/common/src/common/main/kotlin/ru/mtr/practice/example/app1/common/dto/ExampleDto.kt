package ru.mtr.practice.example.app1.common.dto

import kotlinx.serialization.Serializable

@Serializable
data class ExampleDto(val sampleDtoField: String)
