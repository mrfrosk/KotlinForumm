package ru.mtr.practice.example.app1.common

import io.ktor.client.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*

object Kernel {
	val http = HttpClient {
		install(ContentNegotiation) {
			json()
		}
		expectSuccess = false
	}

	fun buildUrl(path: String) = URLBuilder(Url("http://localhost:8080")).run {
		path(path)
		build()
	}
}