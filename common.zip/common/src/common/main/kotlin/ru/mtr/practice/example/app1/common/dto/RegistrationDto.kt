package ru.mtr.practice.example.app1.common.dto
import kotlinx.serialization.Serializable

@Serializable
data class RegistrationDto(var email: String, var password: String, var userName: String)