@file:Suppress("UNUSED_VARIABLE")

import org.jetbrains.kotlin.gradle.tasks.KotlinCompile

plugins {
	apply {
		kotlin("multiplatform")
		kotlin("plugin.serialization")
	}
}
group = "ru.mtr.practice.example"
version = "0.0.1-SNAPSHOT"

tasks.withType<Test> {
	useJUnitPlatform()
}

tasks.withType<KotlinCompile>().configureEach {
	kotlinOptions {
		freeCompilerArgs = listOf("-opt-in=kotlin.RequiresOptIn")
		jvmTarget = "13"
	}
}

kotlin.sourceSets.all {
	languageSettings.optIn("kotlin.RequiresOptIn")
}

kotlin {
	jvm(name = "jvm") {
		compilations.all {
			kotlinOptions.jvmTarget = "13"
			kotlinOptions.freeCompilerArgs = listOf("-Xjsr305=strict", "-opt-in=kotlin.RequiresOptIn")
		}
		testRuns["test"].executionTask.configure {
			useJUnitPlatform()
		}
	}
	js(compiler = LEGACY, name = "js") {
		compilations.all {
			kotlinOptions.freeCompilerArgs = listOf("-opt-in=kotlin.RequiresOptIn")
		}
		binaries.executable()
		browser {
			commonWebpackConfig {
				cssSupport.enabled = true
			}
			testTask {
				useMocha { }
			}
		}
	}
	sourceSets {
		all {
			languageSettings.optIn("kotlinx.serialization.ExperimentalSerializationApi")
			languageSettings.optIn("kotlin.RequiresOptIn")
		}
		val commonMain by getting {
			kotlin.srcDir("src/common/main/kotlin")
			resources.srcDir("src/common/main/resources")
			dependencies {
				implementation(kotlin("stdlib"))
				implementation(kotlin("reflect"))
				implementation(kotlin("serialization"))
				implementation("org.jetbrains.kotlinx:kotlinx-serialization-json")
				implementation("org.jetbrains.kotlinx:kotlinx-datetime")
				implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core")
				implementation("org.jetbrains.kotlinx:kotlinx-coroutines-io")
				implementation("com.benasher44:uuid")
				// ktor
				implementation("io.ktor:ktor-client-core")
				implementation("io.ktor:ktor-client-logging")
				implementation("io.ktor:ktor-client-content-negotiation")
				implementation("io.ktor:ktor-serialization-kotlinx-json")
			}
		}

		tasks.withType<KotlinCompile> {
			kotlinOptions {
				freeCompilerArgs = listOf("-Xjsr305=strict", "-opt-in=kotlin.RequiresOptIn")
				jvmTarget = "13"
			}
		}

		/**
		 * Исходники тестов.
		 */
		val commonTest by getting {
			kotlin.srcDir("src/common/test/kotlin")
			resources.srcDir("src/common/test/resources")
			dependencies {
				implementation(kotlin("stdlib"))
				implementation(kotlin("test"))
				implementation(kotlin("test-annotations-common"))
				implementation("org.jetbrains.kotlin:kotlin-reflect")
			}
		}
		val jvmMain by getting {
			kotlin.srcDir("src/jvm/main/kotlin")
			resources.srcDir("src/jvm/main/resources")
			dependencies {
				implementation("org.jetbrains.kotlin:kotlin-reflect")
			}
		}
		val jvmTest by getting {
			kotlin.srcDir("src/jvm/test/kotlin")
			resources.srcDir("src/jvm/test/resources")
			dependencies {
				implementation(kotlin("test-junit5"))
				implementation(kotlin("test-annotations-common"))
				implementation("org.junit.jupiter:junit-jupiter-engine:5.7.1")
				implementation("org.junit.jupiter:junit-jupiter-api:5.7.1")
				implementation("org.jetbrains.kotlin:kotlin-reflect")
			}
		}

		/**
		 * Основные исходники, которые, в результате, попадут в библиотеку.
		 */
		val jsMain by getting {
			kotlin.srcDir("src/js/main/kotlin")
			resources.srcDir("src/js/main/resources")
			dependencies {
				implementation("org.jetbrains.kotlin:kotlin-reflect")
			}
		}

		/**
		 * Тесты.
		 */
		val jsTest by getting {
			kotlin.srcDir("src/js/test/kotlin")
			resources.srcDir("src/js/test/resources")
			dependencies {
				implementation(kotlin("test-js"))
				implementation(kotlin("test-annotations-common"))
				implementation("org.jetbrains.kotlin:kotlin-reflect")
			}
		}
		targets.all {
			compilations.all {
				kotlinOptions {
					allWarningsAsErrors = true
				}
			}
		}
	}
}
