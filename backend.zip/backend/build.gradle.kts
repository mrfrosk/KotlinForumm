import org.jetbrains.kotlin.gradle.tasks.KotlinCompile

plugins {
	apply {
		id("org.springframework.boot")
		id("io.spring.dependency-management")
		kotlin("jvm")
		kotlin("plugin.spring")
	}
}
fun Project.requireProject(name: String) =
	rootProject.findProject(name) ?: throw Exception("Проект с именем '$name' не найден.")

group = "ru.mtr.practice.example"
version = "0.0.1-SNAPSHOT"


dependencies {
	/**
	 * Kotlin
	 */
	implementation(kotlin("stdlib"))
	implementation(kotlin("reflect"))
	implementation(kotlin("serialization"))
	/**
	 * Spring
	 */
	implementation("org.springframework.boot:spring-boot-starter")
	implementation("org.springframework.boot:spring-boot-starter-web")
	testImplementation("org.springframework.boot:spring-boot-starter-test")
	/**
	 * KotlinX
	 */
	implementation("org.jetbrains.kotlinx:kotlinx-serialization-json")
	implementation("org.jetbrains.kotlinx:kotlinx-datetime")
	implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core")
	implementation("org.jetbrains.kotlinx:kotlinx-coroutines-io")
	/**
	 * PostgreSQL
	 */
	runtimeOnly("org.postgresql:postgresql")
	/**
	 * Exposed
	 */
	implementation("org.jetbrains.exposed:exposed-core")
	implementation("org.jetbrains.exposed:exposed-dao")
	implementation("org.jetbrains.exposed:exposed-jdbc")
	implementation("org.jetbrains.exposed:exposed-java-time")
	implementation("org.jetbrains.exposed:exposed-spring-boot-starter")
	implementation("org.jetbrains.exposed:spring-transaction")
	/**
	 * Остальное
	 */
	implementation(requireProject(":common"))
	implementation("com.benasher44:uuid")
}

tasks.withType<KotlinCompile> {
	kotlinOptions {
		freeCompilerArgs = listOf("-Xjsr305=strict")
		jvmTarget = "13"
	}
}

tasks.withType<Test> {
	useJUnitPlatform()
}
