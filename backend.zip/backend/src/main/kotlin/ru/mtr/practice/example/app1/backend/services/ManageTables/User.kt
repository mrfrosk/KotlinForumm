package ru.mtr.practice.example.app1.backend.services.ManageTables

import org.jetbrains.exposed.sql.Table

object User: Table() {
    val id = integer(name = "primaryKey").autoIncrement()
    var email = varchar("email",50).uniqueIndex()
    var password = text(name="password")
    var username = varchar("username", 50)
    override val primaryKey = PrimaryKey(id)
}