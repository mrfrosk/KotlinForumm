package ru.mtr.practice.example.app1.backend.services.example

import org.springframework.stereotype.Service

@Service("ExampleService")
class ExampleService {

	private var count = 0

	fun sampleServiceFun() = count++
}