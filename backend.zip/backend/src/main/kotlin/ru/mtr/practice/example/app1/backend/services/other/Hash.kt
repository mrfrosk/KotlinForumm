package ru.mtr.practice.example.app1.backend.services.other

import java.math.BigInteger
import java.security.MessageDigest

class Hash {
    fun encrypt(text: String): String {
        val md = MessageDigest.getInstance("SHA-512")
        val messageDigest = md.digest(text.toByteArray())
        val no = BigInteger(1, messageDigest)
        var hashtext = no.toString(16)
        while (hashtext.length < 32) {
            hashtext = "0$hashtext"
        }
        return hashtext
    }
}