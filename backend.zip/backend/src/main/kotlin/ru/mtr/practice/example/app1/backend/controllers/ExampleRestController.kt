package ru.mtr.practice.example.app1.backend.controllers

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import ru.mtr.practice.example.app1.backend.services.ManageTables.Manage
import ru.mtr.practice.example.app1.backend.services.example.ExampleService
import ru.mtr.practice.example.app1.backend.services.other.OtherService
import ru.mtr.practice.example.app1.common.dto.ExampleDto

@RestController
@RequestMapping("example")
class ExampleRestController(
	@Autowired
	val exampleService: ExampleService,
	@Autowired
	val otherService: OtherService,
) {

	@GetMapping("sample-request-1")
	fun sampleRequest1():Int {
		val y = Manage()

		return exampleService.sampleServiceFun()
	}

	@GetMapping("sample-request-2", produces = ["application/json; charset=UTF-8"])
	fun sampleRequest2() = ExampleDto(otherService.otherServiceFun())
}