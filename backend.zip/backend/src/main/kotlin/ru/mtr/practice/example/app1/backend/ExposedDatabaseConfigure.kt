package ru.mtr.practice.example.app1.backend


import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SchemaUtils
import org.jetbrains.exposed.sql.transactions.TransactionManager
import org.jetbrains.exposed.sql.transactions.transaction
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.jdbc.DataSourceBuilder
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import java.sql.SQLException
import javax.sql.DataSource

@Suppress("unused")
@Configuration
class ExposedDatabaseConfigure {
	@Value("\${spring.datasource.url}")
	lateinit var dataSourceUrl: String

	@Value("\${spring.datasource.driverClassName}")
	lateinit var driverClassName: String

	@Value("\${spring.datasource.dbServer.url}")
	lateinit var dbServerUrl: String

	@Value("\${spring.datasource.username}")
	lateinit var dbServerUserName: String

	@Value("\${spring.datasource.password}")
	lateinit var dbServerPassword: String

	@Value("\${spring.datasource.dbName}")
	lateinit var dbName: String

	@get:Bean
	val datasource: DataSource by lazy {
		checkDatabaseExists()
		DataSourceBuilder.create()
			.url(dataSourceUrl)
			.driverClassName(driverClassName)
			.username(dbServerUserName)
			.password(dbServerPassword)
			.build()
	}

	private fun checkDatabaseExists() {
		TransactionManager.defaultDatabase =
			Database.connect(dataSourceUrl, driverClassName, dbServerUserName, dbServerPassword)
		transaction(TransactionManager.defaultDatabase) {
			try {
				connection.metadata { database }
			} catch (t: SQLException) {
				val server = Database.connect(dbServerUrl, driverClassName, dbServerUserName, dbServerPassword)
				transaction(server) {
					connection.autoCommit = true
					SchemaUtils.createDatabase(dbName)
					connection.autoCommit = false
				}
				server.connector().close()
				TransactionManager.defaultDatabase =
					Database.connect(dataSourceUrl, driverClassName, dbServerUserName, dbServerPassword)
			}
		}
	}
}














