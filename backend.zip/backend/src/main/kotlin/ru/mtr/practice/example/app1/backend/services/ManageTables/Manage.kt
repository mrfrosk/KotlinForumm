package ru.mtr.practice.example.app1.backend.services.ManageTables


import org.jetbrains.exposed.sql.SchemaUtils

import org.jetbrains.exposed.sql.transactions.transaction

class Manage {
    init {
        transaction {
            SchemaUtils.create(User)
//            SchemaUtils.create(Post)
//            SchemaUtils.create(AboutMe)
        }
    }





}