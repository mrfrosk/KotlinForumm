package ru.mtr.practice.example.app1.backend.services.other

import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Service

@Service("OtherService")
class OtherService(
	@Value("\${ru.mtr.practice.example.my-sample-property}")
	val mySampleProperty: String
) {
	fun otherServiceFun(): String {

		return mySampleProperty
	}
}