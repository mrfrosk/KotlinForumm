package ru.mtr.practice.example.app1.backend

import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.transactions.transactionScope
import org.springframework.boot.autoconfigure.AutoConfigurationPackage
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.boot.web.servlet.FilterRegistrationBean
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.PropertySource
import org.springframework.web.cors.CorsConfiguration
import org.springframework.web.cors.UrlBasedCorsConfigurationSource
import org.springframework.web.filter.CorsFilter
import org.springframework.web.servlet.config.annotation.CorsRegistry
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter
import ru.mtr.practice.example.app1.backend.controllers.UserDataRestController
import ru.mtr.practice.example.app1.backend.services.ManageTables.User
import ru.mtr.practice.example.app1.common.ExampleRestClient
import ru.mtr.practice.example.app1.common.dto.RegistrationDto

@Suppress("DEPRECATION")
@SpringBootApplication(scanBasePackages = ["ru.mtr.practice.example"])
@AutoConfigurationPackage(basePackages = ["ru.mtr.practice.example"])
@PropertySource("classpath:application.yml", encoding = "UTF-8")
class BackendApplication {

	companion object {
		@JvmStatic
		fun main(args: Array<String>) {
			runApplication<BackendApplication>(*args)

		}
	}


	@Bean
	fun corsConfigurer(): WebMvcConfigurer? {
		return object : WebMvcConfigurerAdapter() {
			override fun addCorsMappings(registry: CorsRegistry) {
				registry.addMapping("/**")
					.allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS").allowedHeaders(
						"Accept",
						"Accept-Encoding",
						"Accept-Language",
						"Connection",
						"Content-Length",
						"Content-Type",
						"Host",
						"Origin",
						"Referer",
						"sec-ch-ua",
						"sec-ch-ua-mobile",
						"Sec-Fetch-Dest",
						"Sec-Fetch-Mode",
						"Sec-Fetch-Site",
						"User-Agent",
					)
					.allowCredentials(true)
					.allowedOriginPatterns("*")
					.allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
			}
		}
	}

	@Bean
	fun corsFilter(): FilterRegistrationBean<CorsFilter>? {
		val source = UrlBasedCorsConfigurationSource()
		val config = CorsConfiguration()
		config.addAllowedOrigin("*")
		config.addAllowedHeader("*")
		config.addAllowedMethod("*")
		source.registerCorsConfiguration("/**", config)
		val bean = FilterRegistrationBean(CorsFilter(source))
		bean.order = 0
		return bean
	}

}