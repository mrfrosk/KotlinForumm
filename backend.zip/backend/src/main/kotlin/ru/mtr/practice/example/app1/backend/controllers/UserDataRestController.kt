package ru.mtr.practice.example.app1.backend.controllers

import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.select
import org.jetbrains.exposed.sql.transactions.transaction
import org.springframework.web.bind.annotation.*
import ru.mtr.practice.example.app1.backend.services.ManageTables.User
import org.springframework.web.bind.annotation.RestController
import ru.mtr.practice.example.app1.backend.services.other.Hash
import ru.mtr.practice.example.app1.common.dto.RegistrationDto
import ru.mtr.practice.example.app1.common.dto.LoginDto

@RestController
@RequestMapping("db")
class UserDataRestController {
    val hash = Hash()
    @PostMapping("user-login")
    fun login(@RequestBody loginInfo: LoginDto): Boolean{
        loginInfo.password = hash.encrypt(loginInfo.password)
        var user = Pair<String, String>("", "")
        transaction {
            user = User.select(User.email eq loginInfo.email).map{it[User.email] to it[User.password]}[0]
        }
        return user.first == loginInfo.email && user.second == loginInfo.password
    }
    @PostMapping("user-registration")
    fun registration(@RequestBody userInfo: RegistrationDto): Boolean{
        val user = transaction { User.select(User.email eq userInfo.email).toList().joinToString() }
        return if(user == ""){
            transaction {
                println(userInfo.userName)
                User.insert {
                    it[email] = userInfo.email
                    it[password] = hash.encrypt(userInfo.password)
                    it[username] = userInfo.userName
                }
            }
            true
        } else{
            false
        }
    }



}