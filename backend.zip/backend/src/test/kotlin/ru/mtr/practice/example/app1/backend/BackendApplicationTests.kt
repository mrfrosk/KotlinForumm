package ru.mtr.practice.example.app1.backend

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class BackendApplicationTests {

	@Test
	fun contextLoads() {
	}

}
